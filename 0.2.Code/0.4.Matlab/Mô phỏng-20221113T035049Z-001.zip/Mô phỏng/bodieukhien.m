function [v,w]=bodieukhien(e2)
v=800;
w=e2*0.04;
end